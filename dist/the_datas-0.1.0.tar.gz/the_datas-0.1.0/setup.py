# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['the_datas']

package_data = \
{'': ['*']}

install_requires = \
['altair>=5.2.0,<6.0.0',
 'numpy>=1.26.2,<2.0.0',
 'pandas>=2.1.4,<3.0.0',
 'statsmodels>=0.14.1,<0.15.0']

setup_kwargs = {
    'name': 'the-datas',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'Andrew Kroening',
    'author_email': '111026320+andrewkroening@users.noreply.github.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
